import { GoogleGenAI } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY || "" });

export async function processNaturalLanguageCommand(userMessage: string): Promise<{ action: string; details: any }> {
  const msg = userMessage.toLowerCase();

  // INSERT: "insert into student table values 101, Asha, asha@gmail.com" or "insert student 101, Asha, asha@gmail.com"
  if (msg.includes("insert")) {
    const insertMatch = userMessage.match(/insert\s+(?:into\s+)?(?:table\s+)?(\w+)\s+(?:table\s+)?(?:values?\s+)?(.+)/i);
    if (insertMatch) {
      const tableName = insertMatch[1];
      const valuesStr = insertMatch[2];
      const values = valuesStr.split(",").map(v => v.trim());
      return { action: "insert_row", details: { tableName, values } };
    }
  }

  // UPDATE: "update student table set name = Ana where id = 102"
  if (msg.includes("update")) {
    const updateMatch = userMessage.match(/update\s+(?:table\s+)?(\w+)\s+(?:table\s+)?set\s+(.+?)\s+where\s+(.+)/i);
    if (updateMatch) {
      return {
        action: "update_row",
        details: { tableName: updateMatch[1], set: updateMatch[2], where: updateMatch[3] }
      };
    }
  }

  // DELETE: "delete from student where id = 101" or "delete student where id = 101"
  if (msg.includes("delete")) {
    const deleteMatch = userMessage.match(/delete\s+(?:from\s+)?(?:table\s+)?(\w+)\s+(?:table\s+)?where\s+(.+)/i);
    if (deleteMatch) {
      return { action: "delete_row", details: { tableName: deleteMatch[1], where: deleteMatch[2] } };
    }
  }

  // CREATE TABLE
  if (msg.includes("create") && (msg.includes("table") || msg.includes("tables"))) {
    const tableMatch = userMessage.match(/(?:create\s+(?:a\s+)?table\s+)(\w+)/i);
    const columnsMatch = userMessage.match(/(?:table\s+\w+\s+(?:with\s+)?)(.*?)$/i);

    if (tableMatch) {
      const tableName = tableMatch[1];
      const columnsText = columnsMatch ? columnsMatch[1] : "";
      const columnsList = columnsText
        .split(",")
        .map(c => c.trim().toLowerCase())
        .filter(c => c)
        .map(col => {
          if (col.includes("email")) return { name: col, type: "text" };
          if (col.includes("id")) return { name: col, type: "integer" };
          if (col.includes("age") || col.includes("count") || col.includes("number") || col.includes("phone")) return { name: col, type: "integer" };
          return { name: col, type: "text" };
        });

      if (columnsList.length > 0) {
        return { action: "create_table", details: { name: tableName, columns: columnsList } };
      }
    }
  }

  // DELETE TABLE
  if ((msg.includes("delete") || msg.includes("drop")) && msg.includes("table")) {
    const tableMatch = userMessage.match(/(?:delete|drop)\s+(?:table\s+)?(\w+)/i);
    if (tableMatch) {
      return { action: "delete_table", details: { tableName: tableMatch[1] } };
    }
  }

  // SHOW SPECIFIC TABLE: "show student table" or "show table student" or "show all columns of student table"
  if (msg.includes("show")) {
    const tableMatch = userMessage.match(/show\s+(?:(?:all\s+columns\s+of\s+)?)?(?:table\s+)?(\w+)(?:\s+table)?/i);
    if (tableMatch && !msg.includes("all table") && !msg.includes("all tables")) {
      return { action: "show_table", details: { tableName: tableMatch[1] } };
    }
  }

  // SHOW ALL TABLES
  if (msg.includes("show") && (msg.includes("all table") || msg.includes("all tables"))) {
    return { action: "show_tables", details: { message: userMessage } };
  }

  // DEFAULT
  return { action: "query", details: { message: userMessage } };
}

export function generateChatResponse(action: string, details: any, result?: any): string {
  if (action === "show_table" && result) {
    const table = result.table;
    const rows = result.rows || [];
    if (!table) return `❌ Table not found`;
    
    // Build table header
    const cols = table.columns || [];
    const header = cols.map((c: any) => c.name).join(" | ");
    const separator = cols.map(() => "---").join("-+-");
    
    // Build table rows
    let tableStr = `📋 TABLE: ${table.name}\n\n${header}\n${separator}\n`;
    if (rows.length === 0) {
      tableStr += "(no rows)";
    } else {
      tableStr += rows.map((row: any) => cols.map((c: any) => String(row.data?.[c.name] || "")).join(" | ")).join("\n");
    }
    return tableStr;
  }

  const responses: { [key: string]: string } = {
    create_table: `✓ Created table "${details.name}" with columns: ${details.columns?.map((c: any) => `${c.name}(${c.type})`).join(", ")}`,
    delete_table: `✓ Deleted table "${details.tableName}"`,
    insert_row: `✓ Inserted row into "${details.tableName}" with values: ${details.values?.join(", ")}`,
    update_row: `✓ Updated rows in "${details.tableName}"`,
    delete_row: `✓ Deleted rows from "${details.tableName}"`,
    show_tables: `📊 Showing all tables in database`,
    query: `Processing: ${details.message || "your request"}`
  };

  return String(responses[action] || `Done: ${details.message || "operation complete"}`);
}

export async function extractTablesFromDocument(text: string): Promise<any[]> {
  const lines = text.split("\n");
  const tables: any[] = [];
  let currentTable: any = null;
  let headerRow: string[] = [];

  for (let i = 0; i < lines.length; i++) {
    const line = lines[i].trim();
    
    if (line.includes("|") && line.includes("-")) {
      if (headerRow.length > 0 && currentTable) {
        currentTable.columns = headerRow.map(h => ({ name: h.trim(), type: "text" }));
        tables.push(currentTable);
        currentTable = null;
        headerRow = [];
      }
    } else if (line.includes("|")) {
      const cells = line.split("|").map(c => c.trim()).filter(c => c);
      
      if (headerRow.length === 0 && cells.length > 0) {
        headerRow = cells;
        currentTable = {
          name: `table_${tables.length + 1}`,
          columns: cells.map(c => ({ name: c.toLowerCase().replace(/\s+/g, "_"), type: "text" })),
          rows: []
        };
      } else if (currentTable && cells.length > 0) {
        const row: any = {};
        cells.forEach((cell, idx) => {
          if (headerRow[idx]) {
            row[headerRow[idx].toLowerCase().replace(/\s+/g, "_")] = cell;
          }
        });
        currentTable.rows.push(row);
      }
    }
  }

  if (currentTable && currentTable.columns) {
    tables.push(currentTable);
  }

  return tables;
}
