import type { Express } from "express";
import { createServer, type Server } from "http";
import { WebSocketServer } from "ws";
import { storage } from "./storage";
import { insertChatMessageSchema, insertDatabaseTableSchema, insertTableRowSchema, insertUploadedDocumentSchema } from "@shared/schema";
import { processNaturalLanguageCommand, generateChatResponse, extractTablesFromDocument } from "./gemini";

export async function registerRoutes(app: Express): Promise<Server> {
  const httpServer = createServer(app);
  const wss = new WebSocketServer({ server: httpServer, path: "/ws" });
  
  let broadcastClients = new Set<any>();

  wss.on("connection", (ws) => {
    broadcastClients.add(ws);
    ws.on("close", () => broadcastClients.delete(ws));
  });

  function broadcast(data: any) {
    const message = JSON.stringify(data);
    broadcastClients.forEach(client => {
      if (client.readyState === 1) {
        client.send(message);
      }
    });
  }

  // Chat routes
  app.post("/api/chat/message", async (req, res) => {
    try {
      const validated = insertChatMessageSchema.parse(req.body);
      
      // Save user message
      const userMessage = await storage.addChatMessage(validated);
      broadcast({ type: "chat", message: userMessage });

      // Process command
      const { action, details } = await processNaturalLanguageCommand(validated.content);
      console.log("Action:", action, "Details:", details);

      let result: any = null;
      let responseText = "";

      // Execute the action
      if (action === "create_table" && details.name && details.columns) {
        try {
          result = await storage.createTable({
            name: details.name,
            columns: details.columns
          });
          responseText = String(generateChatResponse(action, details, result));
          broadcast({ type: "table_created", table: result });
        } catch (error: any) {
          responseText = `❌ Error creating table: ${error.message}`;
        }
      } else if (action === "delete_table" && details.tableName) {
        try {
          const tables = await storage.getTables();
          const tableToDelete = tables.find(t => t.name.toLowerCase() === details.tableName.toLowerCase());
          if (tableToDelete) {
            await storage.deleteTable(tableToDelete.id);
            responseText = String(generateChatResponse(action, details));
            broadcast({ type: "table_deleted", tableId: tableToDelete.id });
          } else {
            responseText = `❌ Table "${details.tableName}" not found`;
          }
        } catch (error: any) {
          responseText = `❌ Error deleting table: ${error.message}`;
        }
      } else if (action === "add_column" && details.tableName && details.columnName) {
        try {
          const tables = await storage.getTables();
          const table = tables.find(t => t.name.toLowerCase() === details.tableName.toLowerCase());
          if (table) {
            const newColumns = [...(table.columns || []), { name: details.columnName, type: details.columnType || "text" }];
            result = await storage.updateTable(table.id, newColumns);
            responseText = String(generateChatResponse(action, details));
            broadcast({ type: "table_updated", table: result });
          } else {
            responseText = `❌ Table "${details.tableName}" not found`;
          }
        } catch (error: any) {
          responseText = `❌ Error adding column: ${error.message}`;
        }
      } else if (action === "insert_row" && details.tableName && details.values) {
        try {
          const tables = await storage.getTables();
          const table = tables.find(t => t.name.toLowerCase() === details.tableName.toLowerCase());
          if (table) {
            const data: any = {};
            table.columns?.forEach((col, idx) => {
              data[col.name] = details.values[idx] || null;
            });
            const newRow = await storage.insertRow({ tableId: table.id, data });
            responseText = String(generateChatResponse(action, details));
            broadcast({ type: "row_inserted", row: newRow });
          } else {
            responseText = `❌ Table "${details.tableName}" not found`;
          }
        } catch (error: any) {
          responseText = `❌ Insert failed: ${error.message}`;
        }
      } else if (action === "update_row" && details.tableName) {
        responseText = String(generateChatResponse(action, details));
      } else if (action === "delete_row" && details.tableName) {
        responseText = String(generateChatResponse(action, details));
      } else if (action === "show_table" && details.tableName) {
        try {
          const tables = await storage.getTables();
          const table = tables.find(t => t.name.toLowerCase() === details.tableName.toLowerCase());
          if (table) {
            const rows = await storage.getRows(table.id);
            responseText = String(generateChatResponse(action, details, { table, rows }));
          } else {
            responseText = `❌ Table "${details.tableName}" not found`;
          }
        } catch (error: any) {
          responseText = `❌ Error: ${error.message}`;
        }
      } else if (action === "show_tables") {
        const tables = await storage.getTables();
        if (tables.length === 0) {
          responseText = "📊 No tables found. Create one by saying 'create a table student with id, name, email'";
        } else {
          responseText = `📊 Found ${tables.length} table(s):\n${tables.map(t => `• ${t.name} (${t.columns?.length || 0} columns)`).join("\n")}`;
        }
      } else {
        responseText = String(generateChatResponse(action, details));
      }

      // Save AI response
      const aiMessage = await storage.addChatMessage({
        content: String(responseText || ""),
        role: "assistant"
      });
      broadcast({ type: "chat", message: aiMessage });

      res.json([userMessage, aiMessage]);
    } catch (error: any) {
      console.error("Chat error:", error);
      res.status(400).json({ error: error.message || "Invalid message" });
    }
  });

  app.get("/api/chat/history", async (req, res) => {
    const history = await storage.getChatHistory();
    res.json(history);
  });

  // Database table routes
  app.post("/api/tables", async (req, res) => {
    try {
      const validated = insertDatabaseTableSchema.parse(req.body);
      const table = await storage.createTable(validated);
      broadcast({ type: "table_created", table });
      res.json(table);
    } catch (error) {
      res.status(400).json({ error: "Invalid table" });
    }
  });

  app.get("/api/tables", async (req, res) => {
    const tables = await storage.getTables();
    res.json(tables);
  });

  app.get("/api/tables/:id", async (req, res) => {
    const table = await storage.getTable(req.params.id);
    if (!table) return res.status(404).json({ error: "Not found" });
    res.json(table);
  });

  app.put("/api/tables/:id", async (req, res) => {
    try {
      const table = await storage.updateTable(req.params.id, req.body.columns);
      broadcast({ type: "table_updated", table });
      res.json(table);
    } catch (error) {
      res.status(400).json({ error: "Invalid update" });
    }
  });

  app.patch("/api/tables/:id/positions", async (req, res) => {
    try {
      const table = await storage.updateTablePositions(req.params.id, req.body);
      broadcast({ type: "table_updated", table });
      res.json(table);
    } catch (error) {
      res.status(400).json({ error: "Invalid update" });
    }
  });

  app.post("/api/tables/:id/columns", async (req, res) => {
    try {
      const table = await storage.addColumn(req.params.id, req.body);
      broadcast({ type: "table_updated", table });
      res.json(table);
    } catch (error) {
      res.status(400).json({ error: "Invalid column" });
    }
  });

  app.patch("/api/tables/:id/columns/:columnName", async (req, res) => {
    try {
      const table = await storage.updateColumn(req.params.id, req.params.columnName, req.body);
      broadcast({ type: "table_updated", table });
      res.json(table);
    } catch (error) {
      res.status(400).json({ error: "Invalid update" });
    }
  });

  app.delete("/api/tables/:id/columns/:columnName", async (req, res) => {
    try {
      const table = await storage.removeColumn(req.params.id, req.params.columnName);
      broadcast({ type: "table_updated", table });
      res.json(table);
    } catch (error) {
      res.status(400).json({ error: "Invalid delete" });
    }
  });

  app.delete("/api/tables/:id", async (req, res) => {
    await storage.deleteTable(req.params.id);
    broadcast({ type: "table_deleted", tableId: req.params.id });
    res.json({ success: true });
  });

  // Row routes
  app.post("/api/rows", async (req, res) => {
    try {
      const validated = insertTableRowSchema.parse(req.body);
      const row = await storage.insertRow(validated);
      broadcast({ type: "row_inserted", row });
      res.json(row);
    } catch (error) {
      res.status(400).json({ error: "Invalid row" });
    }
  });

  app.get("/api/rows/:tableId", async (req, res) => {
    const rows = await storage.getRows(req.params.tableId);
    res.json(rows);
  });

  app.patch("/api/rows/:id", async (req, res) => {
    try {
      const row = await storage.updateRow(req.params.id, req.body.data);
      broadcast({ type: "row_updated", row });
      res.json(row);
    } catch (error) {
      res.status(400).json({ error: "Invalid update" });
    }
  });

  app.delete("/api/rows/:id", async (req, res) => {
    await storage.deleteRow(req.params.id);
    broadcast({ type: "row_deleted", rowId: req.params.id });
    res.json({ success: true });
  });

  // Document upload route
  app.post("/api/documents/upload", async (req, res) => {
    try {
      const { filename, content } = req.body;
      const extractedTables = await extractTablesFromDocument(content);
      const doc = await storage.uploadDocument({
        filename,
        content,
        extractedTables,
      });
      broadcast({ type: "document_uploaded", doc });
      res.json({ doc, extractedTables });
    } catch (error) {
      res.status(400).json({ error: "Upload failed" });
    }
  });

  app.get("/api/documents", async (req, res) => {
    const docs = await storage.getDocuments();
    res.json(docs);
  });

  return httpServer;
}
