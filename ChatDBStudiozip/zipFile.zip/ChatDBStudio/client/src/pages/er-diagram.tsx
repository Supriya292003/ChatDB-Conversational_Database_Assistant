import { useQuery, useMutation } from "@tanstack/react-query";
import { useState } from "react";
import { Loader2, Database, Download, Plus, Trash2, Link2, Key } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { apiRequest, queryClient } from "@/lib/queryClient";

interface Column {
  name: string;
  type: string;
  isPrimaryKey?: boolean;
  foreignKeyTable?: string;
  foreignKeyColumn?: string;
}

interface DatabaseTable {
  id: string;
  name: string;
  columns: Column[];
  positions?: Record<string, { x: number; y: number }>;
}

export default function ERDiagram() {
  const [scale, setScale] = useState(1);
  const [draggedEntity, setDraggedEntity] = useState<string | null>(null);
  const [dragStart, setDragStart] = useState({ x: 0, y: 0 });
  const [showAddAttr, setShowAddAttr] = useState<string | null>(null);
  const [newAttrName, setNewAttrName] = useState("");
  const [newAttrType, setNewAttrType] = useState("text");
  const [editingKey, setEditingKey] = useState<{ table: string; col: string } | null>(null);

  const { data: tables = [], isLoading } = useQuery({
    queryKey: ["/api/tables"],
    queryFn: async () => {
      const result = await apiRequest("GET", "/api/tables");
      return Array.isArray(result) ? result : [];
    },
  });

  const { mutate: updatePositions } = useMutation({
    mutationFn: (params: { tableId: string; positions: any }) =>
      apiRequest("PATCH", `/api/tables/${params.tableId}/positions`, params.positions),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ["/api/tables"] }),
  });

  const { mutate: addColumn } = useMutation({
    mutationFn: (params: { tableId: string; column: any }) =>
      apiRequest("POST", `/api/tables/${params.tableId}/columns`, params.column),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/tables"] });
      setShowAddAttr(null);
      setNewAttrName("");
    },
  });

  const { mutate: removeColumn } = useMutation({
    mutationFn: (params: { tableId: string; colName: string }) =>
      apiRequest("DELETE", `/api/tables/${params.tableId}/columns/${params.colName}`),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ["/api/tables"] }),
  });

  const { mutate: updateColumn } = useMutation({
    mutationFn: (params: { tableId: string; colName: string; updates: any }) =>
      apiRequest("PATCH", `/api/tables/${params.tableId}/columns/${params.colName}`, params.updates),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/tables"] });
      setEditingKey(null);
    },
  });

  const colors = ["#3b82f6", "#ef4444", "#10b981", "#f59e0b", "#8b5cf6"];
  const getColor = (idx: number) => colors[idx % colors.length];

  const handleEntityMouseDown = (e: React.MouseEvent, tableId: string) => {
    if ((e.target as any).closest("button")) return;
    setDraggedEntity(tableId);
    setDragStart({ x: e.clientX, y: e.clientY });
  };

  const handleMouseMove = (e: React.MouseEvent) => {
    if (draggedEntity) {
      const deltaX = e.clientX - dragStart.x;
      const deltaY = e.clientY - dragStart.y;
      const table = Array.isArray(tables) && tables.find(t => t.id === draggedEntity);
      if (table) {
        const pos = (table as any).positions || {};
        const newPos = {
          ...pos,
          [draggedEntity]: {
            x: (pos[draggedEntity]?.x || 100) + deltaX,
            y: (pos[draggedEntity]?.y || 100) + deltaY,
          },
        };
        updatePositions({ tableId: draggedEntity, positions: newPos });
        setDragStart({ x: e.clientX, y: e.clientY });
      }
    }
  };

  if (isLoading) {
    return (
      <div className="flex justify-center items-center h-screen">
        <Loader2 className="w-8 h-8 animate-spin text-primary" />
      </div>
    );
  }

  if (!Array.isArray(tables) || tables.length === 0) {
    return (
      <div className="flex justify-center items-center h-screen">
        <div className="text-center">
          <Database className="w-12 h-12 text-muted-foreground mx-auto mb-2" />
          <p className="text-muted-foreground">No tables yet. Create tables using chat.</p>
        </div>
      </div>
    );
  }

  // Smart auto-layout to prevent overlaps - spread entities with maximum spacing
  const entities = Array.isArray(tables)
    ? tables.map((table, idx) => {
        const pos = (table as any).positions?.[table.id];
        let x, y;
        if (pos) {
          x = pos.x;
          y = pos.y;
        } else {
          // Spread entities far apart: wider cols, more rows
          const col = idx % 2;
          const row = Math.floor(idx / 2);
          x = 50 + col * 900;   // 900px horizontal spacing
          y = 50 + row * 550;   // 550px vertical spacing
        }
        return { ...table, x, y, color: getColor(idx) };
      })
    : [];

  return (
    <div className="flex-1 flex flex-col h-screen bg-background">
      <div className="p-3 border-b border-border bg-card">
        <div className="flex justify-between items-center mb-2">
          <h1 className="text-lg font-bold">Interactive ER Diagram</h1>
          <div className="flex gap-2 text-xs">
            <span>Zoom: {(scale * 100).toFixed(0)}%</span>
            <input
              type="range"
              min="0.5"
              max="3"
              step="0.1"
              value={scale}
              onChange={(e) => setScale(parseFloat(e.target.value))}
              className="w-24"
            />
          </div>
        </div>
        <p className="text-xs text-muted-foreground">Drag entities to move • Click + to add attributes • Click keys to mark primary/foreign</p>
      </div>

      <div
        className="flex-1 bg-muted/20 overflow-auto relative"
        onMouseMove={handleMouseMove}
        onMouseUp={() => setDraggedEntity(null)}
        onMouseLeave={() => setDraggedEntity(null)}
        onWheel={(e) => {
          e.preventDefault();
          setScale(Math.max(0.5, Math.min(3, scale - e.deltaY * 0.001)));
        }}
        style={{ cursor: draggedEntity ? "grabbing" : "grab" }}
      >
        <div
          style={{
            transform: `scale(${scale})`,
            transformOrigin: "0 0",
            transition: draggedEntity ? "none" : "transform 0.2s",
            minWidth: "3000px",
            minHeight: "2000px",
          }}
        >
          <svg className="absolute w-full h-full" style={{ pointerEvents: "none" }}>
            {/* Draw relationships */}
            {entities.flatMap((entity) =>
              (entity.columns as Column[]).flatMap((col) => {
                if (col.foreignKeyTable) {
                  const targetEntity = entities.find(e => e.name === col.foreignKeyTable);
                  if (!targetEntity) return [];
                  return (
                    <line
                      key={`rel-${entity.id}-${col.name}`}
                      x1={entity.x + 130}
                      y1={entity.y + 80}
                      x2={targetEntity.x + 130}
                      y2={targetEntity.y + 20}
                      stroke="#000000"
                      strokeWidth="2"
                      markerEnd="url(#arrowhead)"
                    />
                  );
                }
                return [];
              })
            )}
            <defs>
              <marker id="arrowhead" markerWidth="10" markerHeight="7" refX="9" refY="3.5" orient="auto">
                <polygon points="0 0, 10 3.5, 0 7" fill="#000000" />
              </marker>
            </defs>
          </svg>

          {/* Entities */}
          {entities.map((entity) => (
            <div
              key={entity.id}
              onMouseDown={(e) => handleEntityMouseDown(e, entity.id)}
              style={{
                position: "absolute",
                left: entity.x,
                top: entity.y,
                cursor: "grab",
              }}
            >
              <Card className="w-64 p-3 border-2" style={{ borderColor: entity.color }}>
                <div className="font-bold text-sm mb-2 p-1 bg-muted rounded text-center">
                  {entity.name.toUpperCase()}
                </div>

                <div className="space-y-1 mb-2 max-h-48 overflow-y-auto">
                  {(entity.columns as Column[]).map((col) => (
                    <div key={col.name} className="flex justify-between items-center text-xs p-1 bg-background rounded group">
                      <div className="flex-1">
                        <div className="flex items-center gap-1">
                          {col.isPrimaryKey && <Key className="w-3 h-3 text-yellow-500" />}
                          {col.foreignKeyTable && <Link2 className="w-3 h-3 text-blue-500" />}
                          <span className={col.isPrimaryKey ? "font-bold underline" : ""}>
                            {col.name}
                          </span>
                        </div>
                        <div className="text-muted-foreground text-xs">{col.type}</div>
                        {col.foreignKeyTable && (
                          <div className="text-blue-600 text-xs">→ {col.foreignKeyTable}.{col.foreignKeyColumn}</div>
                        )}
                      </div>
                      <div className="flex gap-0.5 invisible group-hover:visible">
                        <button
                          onClick={() => setEditingKey({ table: entity.id, col: col.name })}
                          className="p-1 hover:bg-muted rounded"
                          title="Set primary/foreign key"
                        >
                          <Key className="w-3 h-3" />
                        </button>
                        <button
                          onClick={() => removeColumn({ tableId: entity.id, colName: col.name })}
                          className="p-1 hover:bg-red-100 dark:hover:bg-red-900 rounded"
                        >
                          <Trash2 className="w-3 h-3 text-red-500" />
                        </button>
                      </div>
                    </div>
                  ))}
                </div>

                <button
                  onClick={() => setShowAddAttr(entity.id)}
                  className="w-full p-1 text-xs bg-primary text-primary-foreground rounded hover:opacity-90"
                >
                  <Plus className="w-3 h-3 inline mr-1" /> Add Attribute
                </button>
              </Card>

              {/* Add Attribute Form */}
              {showAddAttr === entity.id && (
                <Card className="absolute top-full mt-2 w-64 p-3 z-50 border-primary border-2">
                  <input
                    placeholder="Column name"
                    value={newAttrName}
                    onChange={(e) => setNewAttrName(e.target.value)}
                    className="w-full px-2 py-1 text-xs border rounded mb-2"
                  />
                  <select
                    value={newAttrType}
                    onChange={(e) => setNewAttrType(e.target.value)}
                    className="w-full px-2 py-1 text-xs border rounded mb-2"
                  >
                    <option>text</option>
                    <option>integer</option>
                    <option>boolean</option>
                  </select>
                  <div className="flex gap-2">
                    <button
                      onClick={() => {
                        if (newAttrName) addColumn({ tableId: entity.id, column: { name: newAttrName, type: newAttrType } });
                      }}
                      className="flex-1 px-2 py-1 text-xs bg-green-600 text-white rounded hover:bg-green-700"
                    >
                      Add
                    </button>
                    <button
                      onClick={() => setShowAddAttr(null)}
                      className="flex-1 px-2 py-1 text-xs bg-gray-300 rounded hover:bg-gray-400"
                    >
                      Cancel
                    </button>
                  </div>
                </Card>
              )}

              {/* Key Editor */}
              {editingKey?.table === entity.id && (
                <Card className="absolute top-full mt-2 w-72 p-3 z-50 border-primary border-2">
                  <div className="text-xs font-bold mb-2">Edit Key: {editingKey.col}</div>
                  <div className="space-y-2">
                    <label className="flex items-center gap-2">
                      <input
                        type="checkbox"
                        checked={(entity.columns as Column[]).find(c => c.name === editingKey.col)?.isPrimaryKey || false}
                        onChange={(e) =>
                          updateColumn({
                            tableId: entity.id,
                            colName: editingKey.col,
                            updates: { isPrimaryKey: e.target.checked },
                          })
                        }
                      />
                      <span>Primary Key</span>
                    </label>

                    <div>
                      <label className="text-xs">Foreign Key References:</label>
                      <select
                        defaultValue={(entity.columns as Column[]).find(c => c.name === editingKey.col)?.foreignKeyTable || ""}
                        onChange={(e) => {
                          const targetTable = e.target.value;
                          if (targetTable) {
                            const targetEntity = entities.find(t => t.name === targetTable);
                            updateColumn({
                              tableId: entity.id,
                              colName: editingKey.col,
                              updates: {
                                foreignKeyTable: targetTable,
                                foreignKeyColumn: (targetEntity?.columns as Column[])[0]?.name,
                              },
                            });
                          } else {
                            updateColumn({
                              tableId: entity.id,
                              colName: editingKey.col,
                              updates: { foreignKeyTable: null, foreignKeyColumn: null },
                            });
                          }
                        }}
                        className="w-full px-2 py-1 text-xs border rounded"
                      >
                        <option value="">None</option>
                        {entities
                          .filter(e => e.id !== entity.id)
                          .map(e => (
                            <option key={e.id} value={e.name}>
                              {e.name}
                            </option>
                          ))}
                      </select>
                    </div>

                    <button
                      onClick={() => setEditingKey(null)}
                      className="w-full px-2 py-1 text-xs bg-gray-300 rounded hover:bg-gray-400"
                    >
                      Done
                    </button>
                  </div>
                </Card>
              )}
            </div>
          ))}
        </div>
      </div>

      {/* Legend */}
      <div className="p-3 border-t border-border bg-card text-xs space-y-1">
        <div className="flex gap-4">
          <div className="flex items-center gap-2">
            <Key className="w-4 h-4 text-yellow-500" /> Primary Key
          </div>
          <div className="flex items-center gap-2">
            <Link2 className="w-4 h-4 text-blue-500" /> Foreign Key
          </div>
          <div className="flex items-center gap-2">
            <div className="w-8 h-0.5 bg-gray-400 border-dashed" /> Relationship
          </div>
        </div>
      </div>
    </div>
  );
}
