import { useState, useEffect, useRef } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Card } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Send, Loader2 } from "lucide-react";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

interface Message {
  id: string;
  content: any;
  role: "user" | "assistant";
  createdAt: string;
}

const parseTableContent = (content: string) => {
  // Check if content is a formatted table (starts with 📋 TABLE:)
  if (content.includes("📋 TABLE:")) {
    const lines = content.split("\n");
    const titleIdx = lines.findIndex(l => l.includes("📋 TABLE:"));
    if (titleIdx === -1) return null;

    const title = lines[titleIdx].replace("📋 TABLE:", "").trim();
    const headerIdx = titleIdx + 2;
    if (headerIdx >= lines.length) return null;

    const headers = lines[headerIdx].split("|").map(h => h.trim());
    const dataStartIdx = headerIdx + 2;

    if (dataStartIdx >= lines.length) return { title, headers, rows: [] };

    const rows = lines
      .slice(dataStartIdx)
      .filter(line => line.trim() && !line.includes("---"))
      .map(line => line.split("|").map(cell => cell.trim()));

    return { title, headers, rows };
  }
  return null;
};

export default function Chat() {
  const [input, setInput] = useState("");
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const { toast } = useToast();

  useEffect(() => {
    try {
      const protocol = window.location.protocol === "https:" ? "wss:" : "ws:";
      const host = window.location.host || `${window.location.hostname}:${window.location.port || (window.location.protocol === "https:" ? 443 : 80)}`;
      const wsUrl = `${protocol}//${host}/ws`;
      const socket = new WebSocket(wsUrl);
      socket.onmessage = () => {
        queryClient.invalidateQueries({ queryKey: ["/api/chat/history"] });
      };
      socket.onerror = () => {
        console.error("WebSocket error");
      };
      return () => {
        if (socket.readyState === 1) socket.close();
      };
    } catch (error) {
      console.error("WebSocket setup error:", error);
    }
  }, []);

  const { data: messages = [] } = useQuery({
    queryKey: ["/api/chat/history"],
    queryFn: async () => {
      try {
        const result = await apiRequest("GET", "/api/chat/history");
        if (Array.isArray(result)) {
          return result.map((msg: any) => ({
            ...msg,
            content: String(msg.content || "")
          }));
        }
        return [];
      } catch (e) {
        return [];
      }
    },
  });

  const { mutate: sendMessage, isPending } = useMutation({
    mutationFn: (content: string) =>
      apiRequest("POST", "/api/chat/message", { content, role: "user" }),
    onSuccess: () => {
      setInput("");
      queryClient.invalidateQueries({ queryKey: ["/api/chat/history"] });
    },
  });

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  return (
    <div className="flex-1 flex flex-col h-screen bg-background">
      <div className="flex-1 overflow-y-auto p-6 space-y-4 max-w-4xl mx-auto w-full">
        {!messages || messages.length === 0 ? (
          <div className="flex justify-center items-center h-full">
            <div className="text-center">
              <h2 className="text-2xl font-semibold mb-2">Welcome to ChatDB</h2>
              <p className="text-muted-foreground">Try: "create a table student with id, name, email"</p>
            </div>
          </div>
        ) : (
          messages.map((msg: Message) => {
            const tableData = parseTableContent(msg.content);
            return (
              <div key={msg.id} className={`flex ${msg.role === "user" ? "justify-end" : "justify-start"}`}>
                {tableData && msg.role === "assistant" ? (
                  <Card className="max-w-2xl p-4 bg-card">
                    <h3 className="font-bold text-sm mb-2">{tableData.title}</h3>
                    <div className="overflow-x-auto">
                      <Table className="text-xs">
                        <TableHeader>
                          <TableRow>
                            {tableData.headers.map((header, idx) => (
                              <TableHead key={idx} className="bg-black text-white font-bold">
                                {header}
                              </TableHead>
                            ))}
                          </TableRow>
                        </TableHeader>
                        <TableBody>
                          {tableData.rows.length === 0 ? (
                            <TableRow>
                              <TableCell colSpan={tableData.headers.length} className="text-center text-muted-foreground">
                                (no rows)
                              </TableCell>
                            </TableRow>
                          ) : (
                            tableData.rows.map((row, ridx) => (
                              <TableRow key={ridx}>
                                {row.map((cell, cidx) => (
                                  <TableCell key={cidx} className="text-muted-foreground">
                                    {cell}
                                  </TableCell>
                                ))}
                              </TableRow>
                            ))
                          )}
                        </TableBody>
                      </Table>
                    </div>
                  </Card>
                ) : (
                  <Card
                    className={`max-w-xl p-4 whitespace-pre-wrap break-words ${
                      msg.role === "user" ? "bg-primary text-primary-foreground" : "bg-card"
                    }`}
                  >
                    <p className="text-sm">{String(msg.content || "")}</p>
                  </Card>
                )}
              </div>
            );
          })
        )}
        <div ref={messagesEndRef} />
      </div>

      <div className="border-t border-border p-6 max-w-4xl mx-auto w-full">
        <div className="flex gap-3">
          <Textarea
            placeholder="Try: create a table student with id, name, email"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === "Enter" && !e.shiftKey) {
                e.preventDefault();
                if (input.trim()) sendMessage(input);
              }
            }}
            className="resize-none"
            rows={3}
          />
          <Button onClick={() => sendMessage(input)} disabled={!input.trim() || isPending} size="icon" className="h-auto">
            {isPending ? <Loader2 className="w-4 h-4 animate-spin" /> : <Send className="w-4 h-4" />}
          </Button>
        </div>
      </div>
    </div>
  );
}
